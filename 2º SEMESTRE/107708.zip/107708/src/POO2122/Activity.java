package POO2122;

public class Activity {

}
